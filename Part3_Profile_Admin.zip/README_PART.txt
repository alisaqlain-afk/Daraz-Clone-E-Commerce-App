PART 3 - Profile & Admin Panel. Copy these files into lib/ of the Part 1 base project.
